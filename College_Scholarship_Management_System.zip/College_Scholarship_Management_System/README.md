# College Scholarship Management System

A simple web-based scholarship management project using HTML, CSS, JavaScript, PHP and MySQL.

## Modules
- Student Registration/Login
- Scholarship listing
- Scholarship application
- Admin login/dashboard
- Application status management

## Run with XAMPP
1. Copy the project folder into `htdocs`.
2. Start Apache and MySQL.
3. Create a database named `scholarship_db` in phpMyAdmin.
4. Import `database.sql`.
5. Open `http://localhost/College_Scholarship_Management_System/`

## Demo Admin
Username: admin
Password: admin123
