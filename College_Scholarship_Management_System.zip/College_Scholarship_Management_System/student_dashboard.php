<?php session_start(); if(!isset($_SESSION['student_id'])){header('Location: login.php');exit;} include 'db.php'; ?>
<!DOCTYPE html><html><head><title>Student Dashboard</title><link rel="stylesheet" href="style.css"></head><body>
<nav><h2>Student Dashboard</h2><a href="apply.php">Apply Scholarship</a><a href="logout.php">Logout</a></nav>
<div class="container"><h2>Available Scholarships</h2><table><tr><th>Name</th><th>Amount</th><th>Action</th></tr>
<?php $r=$conn->query("SELECT * FROM scholarships"); while($s=$r->fetch_assoc()): ?><tr><td><?=$s['name']?></td><td>₹<?=$s['amount']?></td><td><a href="apply.php?id=<?=$s['id']?>">Apply</a></td></tr><?php endwhile; ?>
</table></div></body></html>