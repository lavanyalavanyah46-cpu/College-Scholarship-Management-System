<?php include 'db.php'; $msg='';
if($_SERVER['REQUEST_METHOD']=='POST'){
$name=$_POST['name']; $email=$_POST['email']; $password=password_hash($_POST['password'],PASSWORD_DEFAULT);
$stmt=$conn->prepare("INSERT INTO students(name,email,password) VALUES(?,?,?)"); $stmt->bind_param("sss",$name,$email,$password);
$msg=$stmt->execute() ? "Registration successful. You can login now." : "Registration failed.";
}?>
<!DOCTYPE html><html><head><title>Registration</title><link rel="stylesheet" href="style.css"></head><body>
<form method="post"><h2>Student Registration</h2><input name="name" placeholder="Full Name" required><input type="email" name="email" placeholder="Email" required><input type="password" name="password" placeholder="Password" required><button>Register</button><p><?=htmlspecialchars($msg)?></p><a href="login.php">Login</a></form></body></html>