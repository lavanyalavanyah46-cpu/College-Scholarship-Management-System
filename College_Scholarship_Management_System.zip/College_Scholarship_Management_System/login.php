<?php session_start(); include 'db.php'; $msg='';
if($_SERVER['REQUEST_METHOD']=='POST'){
$email=$_POST['email']; $password=$_POST['password']; $r=$conn->query("SELECT * FROM students WHERE email='".$conn->real_escape_string($email)."'");
if($r && $r->num_rows){$u=$r->fetch_assoc(); if(password_verify($password,$u['password'])){$_SESSION['student_id']=$u['id'];header('Location: student_dashboard.php');exit;}}
$msg='Invalid email or password.';
}?>
<!DOCTYPE html><html><head><title>Student Login</title><link rel="stylesheet" href="style.css"></head><body>
<form method="post"><h2>Student Login</h2><input type="email" name="email" placeholder="Email" required><input type="password" name="password" placeholder="Password" required><button>Login</button><p><?=htmlspecialchars($msg)?></p><a href="register.php">Create account</a></form></body></html>