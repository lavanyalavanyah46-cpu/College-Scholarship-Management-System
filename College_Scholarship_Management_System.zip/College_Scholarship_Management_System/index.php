<!DOCTYPE html>
<html><head><title>College Scholarship Management System</title><link rel="stylesheet" href="style.css"></head>
<body>
<nav><h2>Scholarship Management System</h2><a href="login.php">Student Login</a><a href="admin_login.php">Admin</a></nav>
<section class="hero"><h1>College Scholarship Management System</h1><p>Apply for scholarships and track your application online.</p><a class="btn" href="register.php">Student Registration</a></section>
</body></html>