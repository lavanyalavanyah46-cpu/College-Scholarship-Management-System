CREATE DATABASE IF NOT EXISTS scholarship_db;
USE scholarship_db;
CREATE TABLE students(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(100) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL);
CREATE TABLE scholarships(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,amount DECIMAL(10,2) NOT NULL);
CREATE TABLE applications(id INT AUTO_INCREMENT PRIMARY KEY,student_id INT,scholarship_id INT,reason TEXT,status VARCHAR(30) DEFAULT 'Pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(student_id) REFERENCES students(id),FOREIGN KEY(scholarship_id) REFERENCES scholarships(id));
INSERT INTO scholarships(name,amount) VALUES ('Merit Scholarship',10000),('Government Scholarship',15000),('Financial Assistance Scholarship',12000);